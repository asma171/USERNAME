# Careful!

You seem to have visited `github.com/submit50/USERNAME`, but you forgot to replace `USERNAME` with your own GitHub username! For instance, if your GitHub username were `jharvard` (which it isn't!), you should have visited `github.com/submit50/jharvard` instead of `github.com/submit50/USERNAME`.

## tl;dr

Visit `github.com/submit50/USERNAME`, where `USERNAME` is your own GitHub username, not `USERNAME` literally!
